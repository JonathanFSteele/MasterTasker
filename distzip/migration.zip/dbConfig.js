module.exports = {
  host: "nmsucssoftdev.cdc9wpdzzghs.us-west-2.rds.amazonaws.com",
  user: "csadmin",
  password: "apples12"
};

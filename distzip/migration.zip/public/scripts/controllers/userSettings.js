app.controller('userSettingsController', function($scope) {
  // create a message to display in our view
  $scope.message = 'Change your display name, profile image, or password here';
  $scope.userEmail = 'email@email';
  $scope.displayName = 'my name';
});
